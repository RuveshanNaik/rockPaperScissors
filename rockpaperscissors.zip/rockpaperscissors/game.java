package rockPaperScissors;
import javax.swing.*;//imports
import java.util.*;
public class game {
public static void main(String[]args){
int user=Integer.parseInt(JOptionPane.showInputDialog(null,"LET'S PLAY ROCK, PAPER, SCISSORS" + "\n" 
        + "PICK A NUMBER FROM 1-3" +"\n" + "[1]-ROCK"+"\n" + "[2]-PAPER"+"\n" + "[3]-SCISSORS" + "\n" + "TO TERMINATE INPUT [0]","ROCK_PAPER_SCISSORS_GAME",JOptionPane.INFORMATION_MESSAGE ));
//******************************************************************************************************************************************************
Random rps = new Random();//selecting random number
int comp;
String compC="";
final int term = 0;
while (!(user==term)){ //while loop
    comp= rps.nextInt(3)+1;
if(comp==1){
compC="ROCK";
}
else                       //choices
if(comp==2){
compC="PAPER";
}
else 
if(comp==3){
compC="SCISSORS";
}
//*****************************************************************************************************************************************************
  if(user==comp){
    JOptionPane.showMessageDialog(null,"IT'S A DRAW","ROCK_PAPER_SCISSORS_GAME",JOptionPane.INFORMATION_MESSAGE);
    }
else 
    if(user==1 &&comp==2||user==2&&comp==3||user==3&&comp==2){ //winning statements
  JOptionPane.showMessageDialog(null,"YOU WIN!!! WELL DONE","ROCK_PAPER_SCISSORS_GAME",JOptionPane.INFORMATION_MESSAGE);
    }
 //*****************************************************************************************************************************************************
else 
    if(user==2 &&comp==1||user==3&&comp==2||user==2&&comp==3){    //losing statements
    JOptionPane.showMessageDialog(null,"YOU LOOSE......BETTER LUCK NEXT TIME","ROCK_PAPER_SCISSORS_GAME",JOptionPane.INFORMATION_MESSAGE);
    }
    user=Integer.parseInt(JOptionPane.showInputDialog(null,"LET'S PLAY ROCK, PAPER, SCISSORS" + "\n" 
        + "PICK A NUMBER FROM 1-3" +"\n" + "[1]-ROCK"+"\n" + "[2]-PAPER"+"\n" + "[3]-SCISSORS" + "\n" + "TO TERMINATE INPUT [0]","ROCK_PAPER_SCISSORS_GAME",JOptionPane.INFORMATION_MESSAGE ));
}
}
}